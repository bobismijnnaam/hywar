#ifndef TEST6003_H
#define TEST6003_H

#include <vector>

std::vector<int> test6003(std::vector<int> ps);

#endif // TEST6003_H
