#include <memory>
#include <vector>
#include <iostream>
#include <string>
#include <algorithm>
#include "CL/cl.hpp"
#include "utils.hpp"

std::vector<int> test6006(std::vector<int> xs, int y);
