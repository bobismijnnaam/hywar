#include <iostream>
#include <vector>

#include "test6003/test6003.hpp"

int main() {
    std::vector<int> testData;
    for (int i = 0; i < 64; i++) {
        testData.push_back(i);
    }

    auto result6003 = test6003(testData);

    for (auto i : result6003) {
        std::cout << i << "\n";
    }

    return 0;
}
