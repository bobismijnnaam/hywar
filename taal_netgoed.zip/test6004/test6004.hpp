#include <memory>
#include <vector>
#include <iostream>
#include <string>
#include <algorithm>
#include "CL/cl.hpp"
#include "utils.hpp"

int test6004(std::vector<int> xs);
