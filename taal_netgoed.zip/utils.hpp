#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>
#include <vector>

std::string replace(std::string source, std::string target, std::string replacement);
std::string params(std::vector<std::string> params_);
std::string braces(std::string inner);

#endif // UTILS_HPP
